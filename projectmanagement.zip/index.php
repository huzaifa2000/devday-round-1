<?php 
include_once 'config/Database.php';
include_once 'class/User.php';

$database = new Database();
$db = $database->getConnection();

$user = new User($db);

if($user->loggedIn()) {
	if($_SESSION["role"] == 'manager') {
		header("Location: clients.php");
	} else if($_SESSION["role"] == 'employee') {
		header("Location: tasks.php");
	}
}

$loginMessage = '';
if(!empty($_POST["login"]) && !empty($_POST["email"]) && !empty($_POST["password"]))
 {	
	$user->email = $_POST["email"];
	$user->password = $_POST["password"];	
	if($user->login()) {
		if($_SESSION["role"] == 'manager') {
			header("Location: clients.php");
		} else if($_SESSION["role"] == 'employee') {
			header("Location: tasks.php");
		}
	}
	
	else
	 {
		$loginMessage = 'Invalid login! Please try again.';
	}
} 

else 
{
	$loginMessage = 'Fill all fields.';
}
include('inc/header.php');
?>
<title>Round 1 Devday Web Development</title>
<?php include('inc/container.php');?>
<body  style="background-image: url('images/bg.jpg'); background-size:cover;">
<div class="content"> 
	<div class="container-fluid">
		<!-- <div class="col-md-4">
			<img class="img-fluid" src="images/index-bg1.jpg" alt="">
		</div> -->
		
				
        <div class="col-md-6">                    
			<div class="panel panel-info">
				<div class="panel-heading" style="background:#005AAC;color:white;">
					<div class="panel-title">Log In</div>                        
				</div> 
				<div style="padding-top:30px" class="panel-body" >
					<?php if ($loginMessage != '') { ?>
						<div id="login-alert" class="alert alert-danger col-sm-12"><?php echo $loginMessage; ?></div>                            
					<?php } ?>
					<form id="loginform" class="form-horizontal" role="form" method="POST" action="">                                    
						<div style="margin-bottom: 25px" class="input-group">
							<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
							<input type="text" class="form-control" id="email" name="email" value="<?php if(!empty($_POST["email"])) { echo $_POST["email"]; } ?>" placeholder="email" style="background:white;" required>                                        
						</div>                                
						<div style="margin-bottom: 25px" class="input-group">
							<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
							<input type="password" class="form-control" id="password" name="password" value="<?php if(!empty($_POST["password"])) { echo $_POST["password"]; } ?>" placeholder="password" required>
						</div>					
						<div style="margin-top:10px" class="form-group">                               
							<div class="col-sm-12 controls">
							<input type="submit" name="login" value="Login" class="btn" style="background-color:#005AAC;color:white;">						  
							</div>						
						</div>				
						<!-- <p>
						<h3>Manager Login</h3>
						<strong>Email:</strong> huzaifa@gmail.com<br>
						<strong>Password:</strong> aassddff
						</p>
						<p>
						<h3>Employee Login:</h3>
						<strong>Email:</strong> william@webdamn.com<br>
						<strong>Password:</strong> 123
						</p> -->
					</form>   
				</div>                     
			</div>  
		</div>       
    </div>        
				
					</body>

